"""Bind processed inputs and the analysis rules before the first candidate invocation."""

from datetime import datetime
from hashlib import sha256
import json
from pathlib import Path
from zoneinfo import ZoneInfo

ROOT = Path(__file__).resolve().parents[1]
LOCK = ROOT / '00_plan/FREEZE.json'
INPUTS = 'implementation_receipt/IMPLEMENTATION_INPUT_MANIFEST.json'
RUNNER = 'implementation_receipt/run_archived_pair.py'
FRAME = 'frame_design/FRAME.json'
REFERENCE = '00_plan/O15_REFERENCE.json'
ORDER = '00_plan/PERMUTATIONS.json'


def read(relative):
    return json.loads((ROOT / relative).read_bytes())


def digest(relative):
    return sha256((ROOT / relative).read_bytes()).hexdigest()


def require(condition, explanation):
    if not condition:
        raise ValueError(explanation)


def main():
    require(not (ROOT / 'execution').exists(), 'Candidate execution directory already exists')
    identity = {row['case_id']: row['context'] for row in read(FRAME)['cases']}
    recorded = read(INPUTS)
    materialised = {row['case_id']: {item['path']: item for item in row['files']}
                    for row in recorded['cases']}
    reference = read(REFERENCE)
    require(reference['frame_sha256'] == digest(FRAME), 'Reference was run on a different frame')
    require(set(identity) == set(materialised) == {row['case_id'] for row in reference['cases']}
            and len(identity) == len(reference['cases']) == 192, 'Frame identities differ')
    for row in reference['cases']:
        members = materialised[row['case_id']]
        for relative, evidence in row['reference_evidence'].items():
            expected = {key: members[relative][key] for key in ('bytes', 'sha256')} if relative in members else None
            require(evidence == expected, f'Reference evidence differs for {row["case_id"]} {relative}')
    for filename, expected_hash in reference['source_sha256'].items():
        require(expected_hash == digest('reference/' + filename), 'Reference source changed before freeze')
    order = read(ORDER)
    require(order['frame_sha256'] == digest(FRAME), 'Permutation frame binding is invalid')
    for context, indices in order['context_orders'].items():
        require(set(indices) == {case for case, label in identity.items() if label == context}
                and len(indices) == len(set(indices)) == 48, 'Incomplete permutation')
    require(set(order['context_orders']) == set(identity.values()), 'Missing context permutation')
    prefixes = ('00_plan', 'evaluation', 'frame_design', 'implementation_receipt', 'reference')
    names = sorted(
        file.relative_to(ROOT).as_posix()
        for prefix in prefixes for file in (ROOT / prefix).iterdir() if file.is_file()
    )
    release = {
        'schema': 'nsc-pros-prerun-freeze/1',
        'local_timestamp': datetime.now(ZoneInfo('Europe/Bucharest')).isoformat(timespec='seconds'),
        'scope': 'New synthetic dossiers, O15 only, 28 adjudications per context',
        'candidate_first_execution_pending_at_freeze': True,
        'implementation_input_manifest_sha256': digest(INPUTS),
        'implementation_runner_sha256': digest(RUNNER),
        'candidate_source_bindings': recorded['sources'],
        'cases': len(identity), 'contexts': sorted(set(identity.values())),
        'files': {name: digest(name) for name in names},
    }
    with LOCK.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(release, handle, sort_keys=True, indent=2)
        handle.write('\n')
    print(digest(LOCK.relative_to(ROOT)))


if __name__ == '__main__':
    main()
