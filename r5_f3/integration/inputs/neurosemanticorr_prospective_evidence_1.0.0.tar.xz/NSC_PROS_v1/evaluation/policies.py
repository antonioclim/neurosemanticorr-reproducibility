"""Seal blind prospective policy selections, then score them against a frozen reference."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction
from hashlib import sha256
import json
from pathlib import Path
import secrets

from exact_hypergeometric import upper_count

BUDGET = 28
CEILING = 6
ALPHA = Fraction(1, 80)
ARMS = ('T_FULL', 'B_ASSERT')
PRIMARY = 'screen_and_uniform'
POLICIES = ('disagreement_only', 'uniform_completion', PRIMARY)
OBLIGATIONS = {f'O{index:02}' for index in range(1, 17)}


def require(condition, explanation):
    if not condition:
        raise ValueError(explanation)


def read(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def write(path, value):
    with path.open('x', encoding='utf-8', newline='\n') as handle:
        json.dump(value, handle, indent=2, sort_keys=True, allow_nan=False)
        handle.write('\n')


def frame_cases(path):
    obj = read(path)
    require(obj['schema'] == 'nsc-r1-prospective-frame/1', 'Frame schema changed')
    cases = {row['case_id']: row['context'] for row in obj['cases']}
    require(len(cases) == len(obj['cases']) == 192, 'Frame is not 192 unique IDs')
    require(sorted(Counter(cases.values()).values()) == [48] * 4, 'Frame context sizes changed')
    require(all(case_id.startswith('R1PROS-') for case_id in cases), 'Nonprospective ID')
    return cases


def lock_order(frame, output):
    cases = frame_cases(frame)
    generator = secrets.SystemRandom()
    context_orders = {}
    for context in sorted(set(cases.values())):
        members = sorted(case for case, label in cases.items() if label == context)
        context_orders[context] = generator.sample(members, k=len(members))
    write(output, {'schema': 'nsc-pros-uniform-permutations/1', 'frame_sha256': digest(frame),
                   'sampler': 'Python secrets.SystemRandom.sample without replacement',
                   'context_orders': context_orders})


def screen(docket):
    """Use only observed claim pointers and alias map, without probe labels or outcomes."""
    try:
        claims = read(docket / 'records/R15_claims.json')['claims']
        aliases = read(docket / 'records/R15_edges.json')['aliases']
        require(type(claims) is list and type(aliases) is dict, 'Invalid screening shape')
        reasons = set()
        for claim in claims:
            token = claim['source_pointer']
            require(type(token) is str, 'Invalid source pointer type')
            if not token.startswith('alias:'):
                continue
            suffix = token.removeprefix('alias:')
            if suffix in aliases and token not in aliases:
                reasons.add('suffix_without_literal')
            if suffix in aliases and token in aliases and aliases[suffix] != aliases[token]:
                reasons.add('conflicting_spelling_targets')
            if any(isinstance(aliases.get(key), str) and aliases[key].startswith('alias:')
                   for key in (suffix, token)):
                reasons.add('alias_to_alias_target')
    except (OSError, ValueError, KeyError, TypeError):
        return {'status': 'unavailable', 'reasons': []}
    return {'status': 'flagged' if reasons else 'unflagged', 'reasons': sorted(reasons)}


def outputs(run, freeze_path, frozen_case_ids):
    execution = read(run / 'RUN_RECEIPT.json')
    require(execution['freeze_sha256'] == digest(freeze_path), 'Execution receipt lacks freeze binding')
    require(execution['cases'] == len(frozen_case_ids), 'Run frame size changed')
    receipts = {}
    for entry in execution['schedule']:
        case, arm = entry['case_id'], entry['arm_id']
        require(case in frozen_case_ids and arm in ARMS and (case, arm) not in receipts,
                'Unexpected invocation identity')
        path = run / case / f'{arm}.receipt.json'
        require(entry['receipt_path'] == f'{case}/{arm}.receipt.json' and digest(path) == entry['sha256'],
                f'Invocation receipt changed for {case} {arm}')
        receipt = read(path)
        require(receipt['case_id'] == case and receipt['arm_id'] == arm
                and receipt['status'] == entry['status'], 'Invocation receipt identity mismatch')
        if receipt['status'] == 'COMPLETED_VALID':
            report_path = run / case / f'{arm}.json'
            require(digest(report_path) == receipt['sha256'] == receipt['raw_report_sha256'],
                    f'Candidate report changed for {case} {arm}')
            report = read(report_path)
            require(report['obligation_vector'] == receipt['obligation_vector']
                    and set(report['obligation_vector']) == OBLIGATIONS
                    and report['aggregate'] == receipt['aggregate'], 'Candidate summary mismatch')
            receipts[case, arm] = report
        else:
            receipts[case, arm] = None
    require(set(receipts) == {(case, arm) for case in frozen_case_ids for arm in ARMS},
            'Run has absent invocation receipts')
    return receipts


def select(frame, order, dockets, run, freeze_path, output):
    frozen = read(freeze_path)
    require(frozen['files']['frame_design/FRAME.json'] == digest(frame), 'Frame changed')
    require(frozen['files']['00_plan/PERMUTATIONS.json'] == digest(order), 'Order changed')
    cases = frame_cases(frame)
    draw = read(order)
    require(draw['frame_sha256'] == digest(frame), 'Draw frame binding mismatch')
    reports = outputs(run, freeze_path, cases)
    case_outputs = {}
    context_selections = {}
    for context, context_order in draw['context_orders'].items():
        context_members = {case for case, label in cases.items() if label == context}
        require(set(context_order) == context_members and len(context_order) == len(context_members) == 48,
                'Draw is not a complete permutation within context')
        disagreements, agreements, missing, flagged = [], [], [], []
        for case in context_order:
            a, b = (reports[case, arm] for arm in ARMS)
            routing = screen(dockets / case)
            if a is None or b is None:
                missing.append(case)
                case_outputs[case] = {'context': context, 'screen': routing, 'comparable': False}
                continue
            statuses = [rep['obligation_vector']['O15'] for rep in (a, b)]
            agree = statuses[0] == statuses[1]
            (agreements if agree else disagreements).append(case)
            if agree and routing['status'] == 'flagged':
                flagged.append(case)
            case_outputs[case] = {
                'context': context, 'screen': routing, 'comparable': True, 'O15': statuses,
                'full_vector_agreement': a['obligation_vector'] == b['obligation_vector'],
                'aggregate_agreement': a['aggregate'] == b['aggregate'],
                'non_O15_nonS': {arm: {key: value for key, value in report['obligation_vector'].items()
                                       if key != 'O15' and value != 'S'}
                                 for arm, report in zip(ARMS, (a, b))},
            }
        context_selections[context] = {}
        for policy in POLICIES:
            flagged_panel = flagged if policy == PRIMARY else []
            certainty = disagreements + flagged_panel
            residual = [case for case in agreements if case not in flagged_panel]
            selected_certainty = certainty[:BUDGET]
            random_draw = residual[:BUDGET - len(selected_certainty)] if policy != POLICIES[0] else []
            context_selections[context][policy] = {
                'certainty_selected': selected_certainty, 'certainty_required': len(certainty),
                'certainty_shortfall': max(0, len(certainty) - BUDGET), 'residual_population': len(residual),
                'residual_draw': random_draw, 'incomparable_pairs': missing,
                'unused_slots': BUDGET - len(selected_certainty) - len(random_draw),
            }
    require(set(case_outputs) == set(cases), 'Missing cases after selection')
    write(output, {'schema': 'nsc-pros-blind-policy-selections/1', 'freeze_sha256': digest(freeze_path),
                   'run_sha256': digest(run / 'RUN_RECEIPT.json'), 'context_selections': context_selections,
                   'case_outputs': case_outputs})


def outcome(confirmed, upper):
    if confirmed > CEILING:
        return 'VIOLATED'
    return 'MET' if upper is not None and upper <= CEILING else 'NOT_ESTABLISHED'


def score_policy(plan, context_cases, errors, agreements, policy):
    sure = set(plan['certainty_selected'])
    random = set(plan['residual_draw'])
    selected = sure | random
    require(len(selected) == len(sure) + len(random) <= BUDGET and selected <= set(context_cases),
            'Selection is inconsistent with the budget or frame')
    confirmed = len(selected & errors)
    deterministic = confirmed + len(agreements - selected) + len(plan['incomparable_pairs'])
    assessed = len(random & errors)
    complete = not (plan['incomparable_pairs'] or plan['certainty_shortfall'])
    random_upper = None
    if complete and policy != POLICIES[0]:
        random_upper = len(sure & errors) + upper_count(plan['residual_population'], len(random),
                                                      assessed, ALPHA)
    best_upper = min(deterministic, random_upper) if random_upper is not None else deterministic
    selected_agreements = selected & agreements
    flagged_review = {case for case in selected_agreements
                      if context_cases[case]['screen']['status'] == 'flagged'}
    return {
        'reviews': len(selected), 'agreement_reviews': len(selected_agreements),
        'reviewed_disagreements': len(selected - agreements),
        'agreement_errors_found': confirmed, 'agreement_errors_missed': len(errors - selected),
        'agreement_reviews_without_agreement_error': len(selected_agreements - errors),
        'flagged_agreements_reviewed': len(flagged_review),
        'flagged_reviews_without_agreement_error': len(flagged_review - errors),
        'certainty_shortfall': plan['certainty_shortfall'], 'unused_slots': plan['unused_slots'],
        'certainty_agreement_errors': len(sure & errors), 'residual_sample': len(random),
        'residual_population': plan['residual_population'], 'residual_errors_sampled': assessed,
        'deterministic_interval': [confirmed, deterministic], 'one_look_upper': random_upper,
        'illustrative_ceiling_status': outcome(confirmed, best_upper if complete else None),
        'found_case_ids': sorted(selected & errors), 'missed_case_ids': sorted(errors - selected),
    }


def score(selection, selection_hash_path, reference, frame, freeze_path, output):
    require(selection_hash_path.read_text(encoding='utf-8').strip() == digest(selection),
            'Blind selection commitment mismatch')
    selected = read(selection)
    frozen = read(freeze_path)
    require(selected['freeze_sha256'] == digest(freeze_path), 'Blind selection freeze mismatch')
    require(frozen['files']['00_plan/O15_REFERENCE.json'] == digest(reference), 'Reference changed')
    require(frozen['files']['frame_design/FRAME.json'] == digest(frame), 'Frame changed')
    reference_data = read(reference)
    require(reference_data['schema'] == 'nsc-pros-o15-reference/1', 'Unexpected reference schema')
    records = reference_data['cases']
    expected = {row['case_id']: row['expected'] for row in records}
    cases = selected['case_outputs']
    require(set(cases) == set(expected) == set(frame_cases(frame)) and len(records) == len(cases)
            and set(expected.values()) <= {'S', 'V', 'U'}, 'Incomplete or invalid frozen reference')
    probe_by_case = {row['case_id']: row['probe'] for row in read(frame)['cases']}
    by_context = defaultdict(dict)
    for case, result in cases.items():
        by_context[result['context']][case] = result
    contexts = {}
    probes = defaultdict(Counter)
    error_cases = []
    for context, group in sorted(by_context.items()):
        agreements = {case for case, result in group.items() if result.get('comparable')
                      and result['O15'][0] == result['O15'][1]}
        errors = {case for case in agreements if group[case]['O15'][0] != expected[case]}
        for case, result in group.items():
            probe = probe_by_case[case]
            probes[probe]['cases'] += 1
            probes[probe]['flagged'] += result['screen']['status'] == 'flagged'
            probes[probe]['agreement_errors'] += case in errors
            if case in errors:
                error_cases.append({'case_id': case, 'context': context, 'probe': probe,
                                    'judgement': result['O15'][0], 'reference': expected[case],
                                    'screen': result['screen']})
        methods = {policy: score_policy(subplan, group, errors, agreements, policy)
                   for policy, subplan in selected['context_selections'][context].items()}
        contexts[context] = {
            'scheduled': len(group), 'comparable': sum(result['comparable'] for result in group.values()),
            'O15_agreements': len(agreements), 'agreement_errors': len(errors),
            'screen_flagged_agreements': sum(group[c]['screen']['status'] == 'flagged' for c in agreements),
            'screen_unavailable': sum(result['screen']['status'] == 'unavailable' for result in group.values()),
            'full_vector_agreements': sum(result.get('full_vector_agreement', False) for result in group.values()),
            'aggregate_agreements': sum(result.get('aggregate_agreement', False) for result in group.values()),
            'non_O15_nonS_pairs': sum(any(result.get('non_O15_nonS', {}).values()) for result in group.values()),
            'reference_counts': dict(Counter(expected[case] for case in group)),
            'total_status_by_arm': {arm: dict(Counter(result['O15'][index] for result in group.values()
                                                      if result['comparable'])) for index, arm in enumerate(ARMS)},
            'policy_results': methods,
        }
    counts = ('reviews', 'agreement_reviews', 'reviewed_disagreements', 'agreement_errors_found',
              'agreement_errors_missed', 'flagged_agreements_reviewed', 'flagged_reviews_without_agreement_error',
              'agreement_reviews_without_agreement_error', 'unused_slots')
    pooled = {policy: {key: sum(row['policy_results'][policy][key] for row in contexts.values())
                       for key in counts} for policy in POLICIES}
    pooled_summary = {key: sum(row[key] for row in contexts.values())
                      for key in ('scheduled', 'comparable', 'O15_agreements', 'agreement_errors',
                                  'screen_flagged_agreements', 'screen_unavailable', 'full_vector_agreements',
                                  'aggregate_agreements', 'non_O15_nonS_pairs')}
    primary_bounds = [row['policy_results'][PRIMARY]['one_look_upper'] for row in contexts.values()]
    write(output, {
        'schema': 'nsc-pros-o15-audit-results/1', 'freeze_sha256': digest(freeze_path),
        'blind_selection_sha256': digest(selection), 'reference_sha256': digest(reference),
        'per_context_budget': BUDGET, 'per_context_illustrative_ceiling': CEILING,
        'per_context_alpha': str(ALPHA), 'contexts': contexts, 'pooled': pooled_summary,
        'pooled_policies': pooled, 'primary_detection_gain': (
            pooled[PRIMARY]['agreement_errors_found'] - pooled['uniform_completion']['agreement_errors_found']),
        'primary_familywise_upper_sum': sum(primary_bounds) if None not in primary_bounds else None,
        'probe_counts_after_unblinding': dict(probes), 'agreement_error_cases': error_cases,
    })


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    phases = parser.add_subparsers(dest='phase', required=True)
    layout = {'order': ('frame', 'output'),
              'select': ('frame', 'order', 'dockets', 'run', 'freeze', 'output'),
              'score': ('selection', 'selection_hash', 'reference', 'frame', 'freeze', 'output')}
    for step, names in layout.items():
        options = phases.add_parser(step)
        for name in names:
            options.add_argument('--' + name.replace('_', '-'), type=Path, required=True)
    args = parser.parse_args()
    command = {'order': lock_order, 'select': select, 'score': score}[args.phase]
    command(*(getattr(args, name) for name in layout[args.phase]))


if __name__ == '__main__':
    main()
