"""Exact finite-frame planning and assessment for a shared agreement-error audit.

The tool computes bounds from counts. It does not draw units, produce labels,
run a checker or establish that an assessment satisfies the sampling design.
"""

from __future__ import annotations

import argparse
import json
from fractions import Fraction
from math import comb


def upper_count(population: int, sample: int, adverse: int, alpha: Fraction) -> int:
    """Largest feasible adverse count whose lower-tail probability exceeds alpha."""
    if not 0 <= adverse <= sample <= population or not 0 < alpha < 1:
        raise ValueError("require 0 <= adverse <= sample <= population and 0 < alpha < 1")
    denominator = comb(population, sample)

    def retained(count: int) -> bool:
        lower = max(0, sample - (population - count))
        upper = min(adverse, sample, count)
        numerator = sum(
            comb(count, k) * comb(population - count, sample - k)
            for k in range(lower, upper + 1)
        )
        return numerator * alpha.denominator > denominator * alpha.numerator

    lo, hi = adverse, population - sample + adverse
    while lo < hi:
        mid = (lo + hi + 1) // 2
        if retained(mid):
            lo = mid
        else:
            hi = mid - 1
    return lo


def minimum_zero_adverse_sample(population: int, allowed: int, alpha: Fraction) -> int:
    """Smallest SRSWOR size that excludes allowed+1 failures if none is observed."""
    if not 0 <= allowed <= population or not 0 < alpha < 1:
        raise ValueError("require 0 <= allowed <= population and 0 < alpha < 1")
    if allowed == population:
        return 0
    first_excluded = allowed + 1

    def excludes(sample: int) -> bool:
        good = population - first_excluded
        if sample > good:
            return True
        return (
            comb(good, sample) * alpha.denominator
            <= comb(population, sample) * alpha.numerator
        )

    lo, hi = 0, population
    while lo < hi:
        mid = (lo + hi) // 2
        if excludes(mid):
            hi = mid
        else:
            lo = mid + 1
    return lo


def status(confirmed: int, upper: int, ceiling: int) -> str:
    if confirmed > ceiling:
        return "CEILING_VIOLATED"
    if upper <= ceiling:
        return "CEILING_MET"
    return "CEILING_NOT_ESTABLISHED"


def alpha_value(text: str) -> Fraction:
    try:
        value = Fraction(text)
    except (ValueError, ZeroDivisionError) as error:
        raise argparse.ArgumentTypeError("alpha must be a decimal or fraction") from error
    if not 0 < value < 1:
        raise argparse.ArgumentTypeError("alpha must be inside (0, 1)")
    return value


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    common = argparse.ArgumentParser(add_help=False)
    common.add_argument("--total", type=int, required=True, help="all paired units, n")
    common.add_argument("--residual", type=int, required=True, help="residual agreements, N")
    common.add_argument("--ceiling", type=int, required=True, help="maximum allowed count across n")
    common.add_argument("--certainty-bad", type=int, default=0, help="confirmed bad agreements in the certainty panel")
    common.add_argument("--certainty-unresolved", type=int, default=0, help="certainty-panel agreements not ruled out as bad")
    common.add_argument("--alpha", type=alpha_value, default=Fraction(1, 20))
    modes = parser.add_subparsers(dest="mode", required=True)
    modes.add_parser("plan", parents=[common], help="size the zero-adverse, one-look audit")
    assess = modes.add_parser("assess", parents=[common], help="compute count bounds from observed results")
    assess.add_argument("--sampled", type=int, required=True)
    assess.add_argument("--sample-bad", type=int, required=True)
    assess.add_argument("--sample-unresolved", type=int, default=0)
    args = parser.parse_args()

    n, N, k = args.total, args.residual, args.ceiling
    confirmed_certainty = args.certainty_bad
    uncertainty_certainty = args.certainty_unresolved
    if n < 1 or not 0 <= N <= n or not 0 <= k <= n:
        parser.error("require total >= 1, 0 <= residual <= total and 0 <= ceiling <= total")
    q = confirmed_certainty + uncertainty_certainty
    if min(confirmed_certainty, uncertainty_certainty) < 0 or q > n - N:
        parser.error("non-negative certainty adverse counts must fit the certainty frame")

    result = {
        "mode": args.mode,
        "total": n,
        "residual_agreements": N,
        "ceiling_count": k,
        "alpha_exact": str(args.alpha),
        "certainty_confirmed_bad": confirmed_certainty,
        "certainty_unresolved": uncertainty_certainty,
        "certainty_upper_count": q,
        "inference_scope": "One preplanned SRSWOR look on the fixed residual agreement frame only.",
    }
    if args.mode == "plan":
        if confirmed_certainty > k:
            result.update(status="CEILING_VIOLATED", zero_adverse_random_sample=None, zero_adverse_deterministic_checks=None)
        elif q > k:
            result.update(status="RESOLVE_CERTAINTY_UNCERTAINTY", zero_adverse_random_sample=None, zero_adverse_deterministic_checks=None)
        else:
            allowed = min(N, k - q)
            result.update(
                status="PLAN_CONDITIONAL_ON_ZERO_ADVERSE",
                residual_allowed_count=allowed,
                zero_adverse_random_sample=minimum_zero_adverse_sample(N, allowed, args.alpha),
                zero_adverse_deterministic_checks=N - allowed,
            )
    else:
        m = args.sampled
        x = args.sample_bad + args.sample_unresolved
        if min(args.sample_bad, args.sample_unresolved) < 0 or not 0 <= x <= m <= N:
            parser.error("require 0 <= sample-bad + sample-unresolved <= sampled <= residual")
        confirmed = confirmed_certainty + args.sample_bad
        deterministic_upper = q + x + N - m
        random_upper = q + upper_count(N, m, x, args.alpha)
        result.update(
            sampled=m,
            sampled_confirmed_bad=args.sample_bad,
            sampled_unresolved=args.sample_unresolved,
            confirmed_lower_count=confirmed,
            deterministic_upper_count=deterministic_upper,
            one_look_random_upper_count=random_upper,
            deterministic_status=status(confirmed, deterministic_upper, k),
            conditional_random_status=status(confirmed, random_upper, k),
        )
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
