# Independent audit of prospective O15 results

**Disposition: PASS for the stated finite-corpus results.** I reconstructed each O15 reference independently from its evidence records. I checked every traceable dossier member against the frozen manifest, checked the 384 raw reports against their run receipts and reconstructed all policy selections from the frozen order. I used linear enumeration of candidate residual failure counts to verify the exact one-sided bounds. The audit checked 5,568 manifest members, 192 separate reference decisions and 384 completed reports. It did not launch the candidate implementations.

All 192 pairs agreed in O15, in their full obligation vectors and in their aggregates. No pair had a non-satisfied obligation outside O15. Under the experimental reference, the 32 shared O15 errors consist of 16 rejected legitimate suffix-only aliases and 16 accepted conflicting dual-key aliases. The two directions cancel in marginal judgement totals. Each checker and the reference return 80 S and 112 V. Comparing these marginals would therefore leave all 32 case-level errors invisible. The false-rejection and false-acceptance fractions in the designed frame are 16/80 and 16/112, respectively.

| Review policy | Cases reviewed | Shared errors found | Shared errors missed | Agreement reviews without a shared error |
| --- | ---: | ---: | ---: | ---: |
| O15 disagreement only | 0 | 0 | 32 | 0 |
| Disagreements plus uniform review | 112 | 19 | 13 | 93 |
| Disagreements plus representation screen and residual uniform review | 112 | 32 | 0 | 80 |

The screen flagged 64 dossiers. Exactly 32 flagged dossiers had a shared error. The 32 flagged controls consisted of 16 alias chains and 16 suffix-only aliases with an independently incorrect claim value, all correctly rejected. The 48 additional random reviews from the unflagged agreements detected zero shared errors. The strategy observed 13 more errors than the budget-matched uniform strategy in this pre-run draw. Given eight actual errors among 48 cases in each context, the conditional expected count for a uniform sample of 28 in each context is 56/3, or approximately 18.67 across all four contexts. This is a descriptive check using the unblinded frame. It is not a separate preregistered test.

| Context | Uniform errors found | Uniform deterministic interval | Uniform one-look upper | Screened errors found | Screened deterministic interval | Screened one-look upper |
| --- | ---: | --- | ---: | ---: | --- | ---: |
| community-library | 5 | 5–25 | 15 | 8 | 8–28 | 15 |
| district-energy | 5 | 5–25 | 15 | 8 | 8–28 | 15 |
| mobility-access | 5 | 5–25 | 15 | 8 | 8–28 | 15 |
| skills-bursary | 4 | 4–24 | 13 | 8 | 8–28 | 15 |

The screened residual frame consists of 32 cases in each context. With a sample of 12 and zero detected residual errors, exact lower-tail inversion at 0.0125 retains at most seven residual errors. The total upper is 15 per context, or a simultaneous upper of 60 across the four contexts by Bonferroni. Certificate excess was established from the lower count of eight per context, above the predeclared tolerance of six. Uniform completion and disagreement-only neither established nor disproved the ceiling from the cases each reviewed. Full unblinding establishes exactly eight shared errors per context. It does not remove the uncertainty that the limited audit would have had before unblinding.

The corpus was constructed to contrast specified representation probes, with the same two archived verifier profiles used in four named simulated contexts. The positive yield comparison concerns the fixed 192-case frame and one uniform draw at a specified budget. The result does not establish effectiveness for previously unspecified failure modes, a field prevalence, transfer to a new workflow profile or reviewer time savings. The O15 reference and this independent reconstruction share the written experimental semantics. They were implemented separately from the candidates, without independently commissioned human adjudication.

Run the independent recomputation from the package root.

```sh
python3 report/recompute_independent_audit.py --root . --run execution --selection evaluation/BLIND_SELECTION.json --results evaluation/PROSPECTIVE_RESULTS.json --output independent_audit_recomputed.json
```
