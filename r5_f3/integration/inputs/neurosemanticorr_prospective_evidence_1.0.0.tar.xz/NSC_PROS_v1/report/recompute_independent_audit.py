"""Independent post-unblinding review of the prospective O15 experiment."""

import argparse
from collections import Counter
from fractions import Fraction
from hashlib import sha256
import json
from math import comb
from pathlib import Path


ARMS = ('T_FULL', 'B_ASSERT')
POLICIES = ('disagreement_only', 'uniform_completion', 'screen_and_uniform')
BUDGET = 28


def ensure(condition, message):
    if not condition:
        raise ValueError(message)


def load(path):
    return json.loads(path.read_bytes())


def digest(path):
    return sha256(path.read_bytes()).hexdigest()


def numeric_or_same(left, right):
    def exact(value):
        if type(value) is int:
            return Fraction(value)
        if isinstance(value, dict) and set(value) == {'denominator', 'numerator'}:
            return Fraction(value['numerator'], value['denominator'])
        return None

    converted = exact(left), exact(right)
    if None not in converted:
        return converted[0] == converted[1]
    return type(left) is type(right) and left == right


def analyse_dossier(docket):
    records = docket / 'records'
    claims = load(records / 'R15_claims.json')['claims']
    edge = load(records / 'R15_edges.json')
    result = load(records / 'R11_result.json')
    aliases = edge['aliases']
    flags = set()
    valid = edge['result_id'] == result['result_id']
    for claim in claims:
        token = claim['source_pointer']
        if token.startswith('alias:'):
            shorthand = token[6:]
            names = [spelling for spelling in (token, shorthand) if spelling in aliases]
            targets = {aliases[name] for name in names}
            if names == [shorthand]:
                flags.add('suffix_without_literal')
            if len(targets) > 1:
                flags.add('conflicting_spelling_targets')
            if any(target.startswith('alias:') for target in targets):
                flags.add('alias_to_alias_target')
            if len(targets) != 1:
                valid = False
                continue
            pointer = next(iter(targets))
        else:
            pointer = token
        if not pointer.startswith('/'):
            valid = False
            continue
        target = result
        try:
            for segment in pointer[1:].split('/'):
                field = segment.replace('~1', '/').replace('~0', '~')
                target = target[int(field)] if isinstance(target, list) else target[field]
            metadata = edge['field_metadata'][pointer]
        except (KeyError, TypeError, IndexError, ValueError):
            valid = False
        else:
            valid &= numeric_or_same(target, claim['value'])
            valid &= all(numeric_or_same(claim[key], metadata[key])
                         for key in ('unit', 'denominator', 'scope'))
    return ('S' if valid else 'V'), sorted(flags)


def hyper_upper(population, sample, hits):
    """Invert the exact lower tail by linear enumeration of all population totals."""
    total_subsets = comb(population, sample)
    retained = []
    for count in range(population + 1):
        possible = sum(comb(count, k) * comb(population - count, sample - k)
                       for k in range(hits + 1)
                       if k <= count and 0 <= sample - k <= population - count)
        if possible * 80 > total_subsets:
            retained.append(count)
    return max(retained)


def by_case(root, run, frame):
    inputs = load(root / 'implementation_receipt/IMPLEMENTATION_INPUT_MANIFEST.json')
    locked = load(root / '00_plan/O15_REFERENCE.json')
    ensure(locked['frame_sha256'] == digest(root / 'frame_design/FRAME.json'),
           'reference frame binding changed')
    schedule = {(row['case_id'], row['arm_id']): row
                for row in load(run / 'RUN_RECEIPT.json')['schedule']}
    sources = {row['case_id']: row for row in inputs['cases']}
    oracle = {row['case_id']: row for row in locked['cases']}
    ids = {row['case_id'] for row in frame}
    ensure(ids == set(sources) == set(oracle) == {case for case, _ in schedule},
           'case identity sets differ')
    ensure(len(schedule) == 2 * len(ids), 'incomplete paired receipt schedule')
    output = {}
    members_checked = 0
    raw_reports = 0
    for case in sorted(ids):
        docket = root / 'dockets' / case
        listed = {file['path']: file for file in sources[case]['files']}
        actual = {path.relative_to(docket).as_posix() for path in docket.rglob('*') if path.is_file()}
        ensure(actual == set(listed), f'dossier manifest member mismatch {case}')
        for path, item in listed.items():
            member = docket / path
            ensure(member.stat().st_size == item['bytes'] and digest(member) == item['sha256'],
                   f'dossier manifest bytes mismatch {case} {path}')
            members_checked += 1
        for path, record in oracle[case]['reference_evidence'].items():
            ensure(path in listed and all(listed[path][key] == record[key] for key in ('bytes', 'sha256')),
                   f'reference evidence binding differs {case} {path}')
        label, flags = analyse_dossier(docket)
        ensure(label == oracle[case]['expected'], f'independent O15 reference disagreement {case}')
        reports = []
        for arm in ARMS:
            item = schedule[case, arm]
            receipt_path = run / item['receipt_path']
            receipt = load(receipt_path)
            ensure(digest(receipt_path) == item['sha256'] and receipt['case_id'] == case
                   and receipt['arm_id'] == arm and item['status'] == receipt['status'],
                   f'run receipt mismatch {case} {arm}')
            if receipt['status'] == 'COMPLETED_VALID':
                report_path = run / receipt['report_path']
                ensure(digest(report_path) == receipt['sha256'], f'run report digest mismatch {case} {arm}')
                report = load(report_path)
                ensure(report['case_id'] == case and report['arm_id'] == arm
                       and report['obligation_vector'] == receipt['obligation_vector']
                       and report['aggregate'] == receipt['aggregate'], f'run report mismatch {case} {arm}')
                reports.append(report)
                raw_reports += 1
        paired = len(reports) == 2
        agrees = paired and reports[0]['obligation_vector']['O15'] == reports[1]['obligation_vector']['O15']
        output[case] = {'paired': paired, 'agrees': agrees,
                        'flags': flags, 'reference': label,
                        'error': agrees and reports[0]['obligation_vector']['O15'] != label,
                        'full_vector_agrees': paired and reports[0]['obligation_vector'] == reports[1]['obligation_vector'],
                        'aggregate_agrees': paired and reports[0]['aggregate'] == reports[1]['aggregate'],
                        'has_nonO15_nonS': paired and any(value != 'S' for report in reports
                                                         for key, value in report['obligation_vector'].items()
                                                         if key != 'O15')}
    return output, members_checked, raw_reports


def full_audit(root, run, selection_path, results_path):
    frame_path = root / 'frame_design/FRAME.json'
    frame = load(frame_path)['cases']
    order = load(root / '00_plan/PERMUTATIONS.json')
    audited, members_checked, raw_reports = by_case(root, run, frame)
    observed = load(results_path)
    selected = load(selection_path)['context_selections']
    ensure(order['frame_sha256'] == digest(frame_path), 'permutation bound to wrong frame')
    grouped = {}
    pool = {name: Counter() for name in POLICIES}
    for context, permutation in order['context_orders'].items():
        context_ids = {row['case_id'] for row in frame if row['context'] == context}
        ensure(set(permutation) == context_ids and len(permutation) == len(context_ids) == 48,
               f'invalid permutation {context}')
        group = {case: audited[case] for case in context_ids}
        agree = [case for case in permutation if group[case]['agrees']]
        disagree = [case for case in permutation if group[case]['paired'] and not group[case]['agrees']]
        incomplete = set(permutation) - set(agree) - set(disagree)
        flagged = [case for case in agree if group[case]['flags']]
        actual_errors = {case for case in agree if group[case]['error']}
        totals = {'comparable': len(agree) + len(disagree), 'O15_agreements': len(agree),
                  'agreement_errors': len(actual_errors), 'screen_flagged_agreements': len(flagged),
                  'full_vector_agreements': sum(row['full_vector_agrees'] for row in group.values()),
                  'aggregate_agreements': sum(row['aggregate_agrees'] for row in group.values()),
                  'non_O15_nonS_pairs': sum(row['has_nonO15_nonS'] for row in group.values())}
        ensure(all(observed['contexts'][context][key] == value for key, value in totals.items()),
               f'audit context totals differ {context}')
        policy_results = {}
        for policy in POLICIES:
            risk_cases = flagged if policy == POLICIES[-1] else []
            certainty = (disagree + risk_cases)[:BUDGET]
            residual = [case for case in agree if case not in risk_cases]
            draw = residual[:BUDGET - len(certainty)] if policy != POLICIES[0] else []
            policy_record = selected[context][policy]
            ensure(certainty == policy_record['certainty_selected'] and draw == policy_record['residual_draw'],
                   f'independent blind-order reconstruction differs {context} {policy}')
            judged = set(certainty + draw)
            found = judged & actual_errors
            missed = actual_errors - judged
            lower = len(found)
            upper = lower + len(set(agree) - judged) + len(incomplete)
            sure_errors = len(actual_errors & set(certainty))
            observed_residual_errors = len(actual_errors & set(draw))
            exact = None
            if policy != POLICIES[0] and not incomplete and len(disagree + risk_cases) <= BUDGET:
                exact = sure_errors + hyper_upper(len(residual), len(draw), observed_residual_errors)
            flagged_reviewed = judged & set(flagged)
            numbers = {'reviews': len(judged), 'agreement_reviews': len(judged & set(agree)),
                       'reviewed_disagreements': len(judged & set(disagree)),
                       'unused_slots': BUDGET - len(judged), 'agreement_errors_found': lower,
                       'agreement_errors_missed': len(missed), 'flagged_agreements_reviewed': len(flagged_reviewed),
                       'flagged_reviews_without_agreement_error': len(flagged_reviewed - actual_errors),
                       'agreement_reviews_without_agreement_error': len((judged & set(agree)) - actual_errors),
                       'certainty_agreement_errors': sure_errors, 'residual_population': len(residual),
                       'residual_sample': len(draw), 'residual_errors_sampled': observed_residual_errors,
                       'deterministic_interval': [lower, upper], 'one_look_upper': exact,
                       'found_case_ids': sorted(found), 'missed_case_ids': sorted(missed)}
            published = observed['contexts'][context]['policy_results'][policy]
            ensure(all(published[key] == value for key, value in numbers.items()),
                   f'policy outcomes or interval differ {context} {policy}')
            for key in observed['pooled_policies'][policy]:
                pool[policy][key] += numbers[key]
            policy_results[policy] = numbers
        grouped[context] = {**totals, 'policies': policy_results}
    gain = pool[POLICIES[-1]]['agreement_errors_found'] - pool[POLICIES[1]]['agreement_errors_found']
    bounds = [context['policies'][POLICIES[-1]]['one_look_upper'] for context in grouped.values()]
    familywise = sum(bounds) if None not in bounds else None
    ensure(pool == observed['pooled_policies'] and gain == observed['primary_detection_gain']
           and familywise == observed['primary_familywise_upper_sum'], 'pooled audit outcome differs')
    return {'schema': 'nsc-pros-independent-post-run-audit/1', 'status': 'PASS',
            'dossier_members_checked': members_checked, 'reference_labels_independently_reconstructed': len(audited),
            'raw_reports_checked': raw_reports, 'source_sha256': {'evaluator_results': digest(results_path),
            'blind_selections': digest(selection_path), 'run_receipt': digest(run / 'RUN_RECEIPT.json'),
            'reference': digest(root / '00_plan/O15_REFERENCE.json')}, 'contexts': grouped,
            'pooled_policies': pool, 'primary_detection_gain': gain, 'primary_familywise_upper_sum': familywise}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for path in ('root', 'run', 'selection', 'results', 'output'):
        parser.add_argument('--' + path, type=Path, required=True)
    args = parser.parse_args()
    audit = full_audit(args.root, args.run, args.selection, args.results)
    with args.output.open('x', encoding='utf-8') as stream:
        json.dump(audit, stream, indent=2, sort_keys=True)
        stream.write('\n')


if __name__ == '__main__':
    main()
