# Test prospectiv al auditului pe acorduri

**neuroSEMANTICorr R1 · 23 noiembrie 2026 · Raport de cercetare intern**

## 32 față de 19 erori detectate la același buget

Cele două verificatoare au produs aceleași judecăți O15, aceiași vectori și aceleași verdicte în toate cele 192 de dosare. Raportarea distribuțiilor marginale ar fi ascuns și ea erorile. Referința și fiecare verificator au clasificat 80 de dosare ca satisfăcute și 112 ca încălcări. Judecățile au diferit însă în 32 de cazuri. O15 este obligația care leagă afirmația de valoarea și metadatele sursei din dosar.

| Politică | Adjudecări | Erori găsite | Erori ratate |
| --- | ---: | ---: | ---: |
| Doar dezacorduri | 0 | 0 | 32 |
| Dezacorduri, apoi eșantionare uniformă | 112 | 19 | 13 |
| Dezacorduri, triaj structural și eșantionare | 112 | 32 | 0 |

Au fost planificate 28 de adjudecări pe context. Politica bazată exclusiv pe dezacorduri a lăsat toate cele 112 de locuri nefolosite. Celelalte două politici au folosit întregul buget. Triajul a adăugat 13 descoperiri. Dintre cele 64 de dosare semnalate, 32 aveau judecăți conforme cu referința. Auditarea tuturor acordurilor semnalate are, așadar, și cost de revizie.

## Două mecanisme de eroare, în direcții opuse

- **16 respingeri eronate.** Pentru un token `alias:key`, numai cheia `key` era prezentă și ducea la sursa corectă. Gramatica prospectivă admitea această reprezentare. Ambele verificatoare au raportat încălcarea O15.
- **16 admiteri eronate.** Cheile `alias:key` și `key` trimiteau la surse diferite, iar afirmația corespundea primei. Gramatica prospectivă cere aceeași destinație când există ambele chei. Ambele verificatoare au trecut cazul pe baza aceleiași interpretări.

Când existau două chei către aceeași sursă, toate cele 16 dosare de control au fost judecate conform referinței. Cele 16 lanțuri de aliasuri și cele 16 aliasuri valide ca formă, dar cu valoare declarată greșită, au fost semnalate și judecate conform referinței. A doua familie de erori demonstrează o consecință distinctă a ambiguității, în cadrul regulilor fixate pentru experiment.

## Ce ar fi putut afirma un auditor cu bugetul fixat

| Context simulat | Uniform, erori găsite | Triaj, erori găsite | Limită superioară pentru triaj |
| --- | ---: | ---: | ---: |
| Biblioteci comunitare | 5 | 8 | 15 |
| Energie la nivel de district | 5 | 8 | 15 |
| Acces la mobilitate | 5 | 8 | 15 |
| Burse de competențe | 4 | 8 | 15 |

În fiecare context, strategia cu triaj a verificat toate cele 16 acorduri semnalate. Apoi a verificat aleatoriu 12 dintre cele 32 de acorduri rămase și n-a observat o eroare în eșantion. La nivel unilateral 0,0125, limita exactă rămasă în segmentul nesemnalat a fost de șapte erori pe context. Adăugând cele opt erori confirmate, intervalul de la numărul observat la limita superioară a fost 8–15 pe context. Suma limitelor este 60 pentru cele patru contexte, cu acoperire simultană conservatoare de cel puțin 95%. Fără ipoteza de eșantionare, intervalul determinist a fost 8–28 pe context.

Cele opt erori confirmate în fiecare context au depășit pragul ilustrativ de șase. Politica uniformă, cu patru sau cinci erori observate pe context, a lăsat verdictul despre acel prag nedeterminat în toate cele patru contexte. Referința completă, folosită pentru evaluarea experimentului, a confirmat că triajul a găsit toate erorile din acest set. În condițiile unui audit limitat la cele 112 adjudecări, n-ar fi putut certifica absența altor erori.

## Ce am fixat și executat

1. Am construit 192 de dosare sintetice noi cu un singur dosar pe unitate, câte 48 în fiecare context și câte patru pe fiecare dintre 12 tipuri de caz. Două contexte folosesc W1 și două folosesc W2. Frecvențele tipurilor de caz provin din proiectarea experimentului.
2. Înainte de prima rulare am fixat dosarele, profilul, cele două implementări, regulile de selecție, permutările uniforme și verdictele referinței O15. Referința folosește o implementare redactată separat, din specificație și evidența din dosar. Listele selectate de cele trei politici au fost fixate înainte de scorare, fără acces al codului de selecție la verdictele de referință.
3. Am rulat codul celor două verificatoare arhivate pe Linux cu CPython 3.12.14. Toate cele 384 de invocări au produs rapoarte valide. Ambele verificatoare au primit aceiași octeți ai dosarului din fiecare pereche. Toate celelalte 15 obligații au fost S în toate rapoartele. O verificare separată a refăcut numărătorile și limitele direct din rapoarte, selecții și documentele pentru referință.

## Ce susțin aceste rezultate

Pe acest set sintetic, triajul prespecificat a descoperit mai multe erori comune la același număr de dosare revizuite. Direcțiile opuse ale erorilor arată de ce frecvențele agregate și acordul între verificatoare pot coincide chiar când judecata la nivel de dosar este greșită. Cele două mecanisme se raportează la gramatica prospectivă explicită. Testul păstrează instrumentele istorice și evaluează cazuri noi în profilurile lor existente.

Setul a fost construit deliberat pentru a include situațiile structurale folosite de regulă. Cele patru contexte sunt simulate și împart aceeași metodă de generare. Experimentul oferă dovezi pe acest set, cu o referință separată procedural în cadrul proiectului. Rămân de verificat transferul la alte profiluri, comportamentul pe fluxuri reale și timpul de adjudecare umană.

## Dosarul de reproducibilitate

Pachetul include planul și amprentele dinaintea execuției, 192 de dosare, 384 de rapoarte și recipisele lor, referința O15 pe caz, listele de selecție, rezultate și audit independent. Arhiva istorică P4 rămâne sursa exactă a celor două verificatoare și a profilului folosit în experiment.
