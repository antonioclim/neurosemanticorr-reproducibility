"""Hand-derived calibration cases for the O15 reference, outside the new frame."""

from copy import deepcopy
import json
from pathlib import Path
from tempfile import TemporaryDirectory
import unittest

from oracle import RECORDS, adjudicate
from seal_reference import seal


BASE_POINTER = '/values/total'
METADATA = {'unit': 'count', 'denominator': 17, 'scope': 'finite_table'}
BASE_DOCUMENTS = {
    'claims': {'claims': [{
        'claim_id': 'calibration-a', 'source_pointer': BASE_POINTER, 'value': 3, **METADATA,
    }]},
    'edges': {'result_id': 'synthetic-calibration', 'aliases': {},
              'field_metadata': {BASE_POINTER: METADATA}},
    'result': {'result_id': 'synthetic-calibration', 'values': {'total': 3}},
}


class ReferenceTests(unittest.TestCase):
    def inspect(self, documents):
        with TemporaryDirectory() as folder:
            docket = Path(folder)
            self.write_docket(docket, documents)
            return adjudicate(docket)

    def write_docket(self, docket, documents):
        (docket / 'records').mkdir(parents=True)
        for record, contents in documents.items():
            data = contents if isinstance(contents, bytes) else json.dumps(contents).encode('utf-8')
            (docket / RECORDS[record]).write_bytes(data)

    def test_source_conventions(self):
        cases = (
            (BASE_POINTER, {}, 'S'),
            ('alias:total', {'total': BASE_POINTER}, 'S'),
            ('alias:total', {'alias:total': BASE_POINTER}, 'S'),
            ('alias:total', {'total': BASE_POINTER, 'alias:total': BASE_POINTER}, 'S'),
            ('alias:total', {'total': BASE_POINTER, 'alias:total': '/unrelated'}, 'V'),
            ('alias:total', {}, 'V'),
            ('alias:total', {'total': 'alias:second', 'second': BASE_POINTER}, 'V'),
            ('alias:', {'': BASE_POINTER}, 'V'),
            ('', {}, 'V'),
            ('#/values/total', {}, 'V'),
        )
        for token, aliases, expected in cases:
            with self.subTest(token=token, aliases=aliases):
                documents = deepcopy(BASE_DOCUMENTS)
                documents['claims']['claims'][0]['source_pointer'] = token
                documents['edges']['aliases'] = aliases
                self.assertEqual(self.inspect(documents)['expected'], expected)

    def test_exact_value_types(self):
        cases = (
            (3, {'numerator': 6, 'denominator': 2}, 'S'),
            ({'numerator': -2, 'denominator': 4}, {'numerator': -1, 'denominator': 2}, 'S'),
            (True, 1, 'V'),
            ('1', 1, 'V'),
            (None, False, 'V'),
            (None, None, 'S'),
            ({'numerator': True, 'denominator': 1}, 1, 'V'),
            ({'numerator': 1, 'denominator': 0}, 1, 'V'),
            (3.0, 3, 'V'),
        )
        for claim, result, expected in cases:
            with self.subTest(claim=claim, result=result):
                documents = deepcopy(BASE_DOCUMENTS)
                documents['claims']['claims'][0]['value'] = claim
                documents['result']['values']['total'] = result
                self.assertEqual(self.inspect(documents)['expected'], expected)

    def test_rfc_pointer_traversal(self):
        cases = (
            ('/values/a~1b~0c/0', 'S'),
            ('/values/a~1b~0c/00', 'V'),
            ('/values/a~1b~0c/-', 'V'),
            ('/values/a~1b~0c/1', 'V'),
            ('/values/a~1b~2c/0', 'V'),
            ('/values/~01', 'S'),
            ('/values/', 'S'),
        )
        for pointer, expected in cases:
            with self.subTest(pointer=pointer):
                documents = deepcopy(BASE_DOCUMENTS)
                documents['claims']['claims'][0]['source_pointer'] = pointer
                documents['edges']['field_metadata'][pointer] = METADATA
                documents['result']['values'] = {'a/b~c': [3], '~1': 3, '': 3}
                self.assertEqual(self.inspect(documents)['expected'], expected)

    def test_result_identity_and_metadata(self):
        for owner, field, value in (
            ('claim', 'unit', 'people'), ('claim', 'scope', 'external'),
            ('claim', 'denominator', 8), ('claim', 'denominator', True),
            ('claim', 'denominator', -1), ('metadata', 'scope', 7),
            ('result', 'result_id', 'other'), ('result', 'result_id', 1),
        ):
            with self.subTest(owner=owner, field=field, value=value):
                documents = deepcopy(BASE_DOCUMENTS)
                records = {'claim': documents['claims']['claims'][0],
                           'metadata': documents['edges']['field_metadata'][BASE_POINTER],
                           'result': documents['result']}
                records[owner][field] = value
                self.assertEqual(self.inspect(documents)['expected'], 'V')
        documents = deepcopy(BASE_DOCUMENTS)
        documents['edges']['field_metadata'].clear()
        self.assertEqual(self.inspect(documents)['expected'], 'V')

    def test_missing_files_and_malformed_present_documents(self):
        for record in RECORDS:
            with self.subTest(record=record):
                documents = deepcopy(BASE_DOCUMENTS)
                del documents[record]
                result = self.inspect(documents)
                self.assertEqual(result['expected'], 'U')
                self.assertEqual(result['rationale']['missing'], [RECORDS[record]])
        for present in (b'not-json', b'\xff', b'{"values":1,"values":2}', b'{"values":NaN}', b'[]'):
            with self.subTest(present=present):
                documents = deepcopy(BASE_DOCUMENTS)
                documents['result'] = present
                self.assertEqual(self.inspect(documents)['expected'], 'V')

    def test_multiple_claims_and_precedence(self):
        documents = deepcopy(BASE_DOCUMENTS)
        second = deepcopy(documents['claims']['claims'][0])
        documents['claims']['claims'].append(second)
        self.assertEqual(self.inspect(documents)['expected'], 'V')
        second['claim_id'] = 'calibration-b'
        self.assertEqual(self.inspect(documents)['expected'], 'S')
        second['value'] = 4
        self.assertEqual(self.inspect(documents)['expected'], 'V')
        del documents['result']
        second['unit'] = 'different'
        decision = self.inspect(documents)
        self.assertEqual(decision['expected'], 'V')
        self.assertEqual(decision['rationale']['missing'], [RECORDS['result']])

    def test_seal_binds_case_evidence_and_frame(self):
        with TemporaryDirectory() as folder:
            root = Path(folder)
            frame = root / 'frame.json'
            case_id = 'R1PROS-' + '3' * 24
            docs = deepcopy(BASE_DOCUMENTS)
            self.write_docket(root / case_id, docs)
            rows = [{'case_id': case_id}]
            spec = {'schema': 'nsc-r1-prospective-frame/1', 'cases': rows}
            frame.write_text(json.dumps(spec), encoding='utf-8')
            output = seal(frame, root)
            self.assertEqual(output['cases'][0]['expected'], 'S')
            self.assertEqual(output['cases'][0]['case_id'], case_id)
            self.assertTrue(output['cases'][0]['reference_evidence'][RECORDS['claims']]['sha256'])
            self.assertEqual(len(output['frame_sha256']), 64)
            self.assertEqual(len(output['source_sha256']), 3)
            rows.append({'case_id': case_id})
            frame.write_text(json.dumps(spec), encoding='utf-8')
            with self.assertRaisesRegex(ValueError, 'repeated'):
                seal(frame, root)


if __name__ == '__main__':
    unittest.main()
