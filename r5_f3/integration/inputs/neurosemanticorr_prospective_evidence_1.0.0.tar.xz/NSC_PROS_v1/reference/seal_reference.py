"""Commit the independent O15 decisions before checker execution."""

import argparse
import hashlib
import json
from pathlib import Path
import re

from oracle import RECORDS, adjudicate


def sha256(data):
    return hashlib.sha256(data).hexdigest()


def record_hashes(docket):
    hashes = {}
    for relative_path in RECORDS.values():
        path = docket / relative_path
        if path.is_symlink():
            raise ValueError(f'symlink found in reference evidence: {path}')
        try:
            raw = path.read_bytes()
        except FileNotFoundError:
            hashes[relative_path] = None
        else:
            hashes[relative_path] = {'bytes': len(raw), 'sha256': sha256(raw)}
    return hashes


def seal(frame_path, dockets):
    frame_bytes = frame_path.read_bytes()
    frame = json.loads(frame_bytes)
    if frame.get('schema') != 'nsc-r1-prospective-frame/1':
        raise ValueError('unexpected case-frame schema')
    case_ids = [row['case_id'] for row in frame['cases']]
    if not case_ids or len(set(case_ids)) != len(case_ids):
        raise ValueError('case frame is empty or contains repeated identifiers')
    cases = []
    for case_id in case_ids:
        if re.fullmatch(r'R1PROS-[A-F0-9]{24}', case_id) is None:
            raise ValueError('invalid case identifier')
        dossier = dockets / case_id
        if not dossier.is_dir() or dossier.is_symlink():
            raise ValueError(f'expected a dossier directory for {case_id}')
        evidence = record_hashes(dossier)
        adjudication = adjudicate(dossier)
        if evidence != record_hashes(dossier):
            raise ValueError(f'dossier changed during the reference pass: {case_id}')
        cases.append({'case_id': case_id, **adjudication, 'reference_evidence': evidence})
    reference_dir = Path(__file__).resolve().parent
    return {
        'schema': 'nsc-pros-o15-reference/1',
        'scope': 'O15 only',
        'frame_sha256': sha256(frame_bytes),
        'source_sha256': {
            name: sha256((reference_dir / name).read_bytes())
            for name in ('oracle.py', 'seal_reference.py', 'REFERENCE_METHOD.md')
        },
        'cases': cases,
    }


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--dockets', required=True, type=Path)
    parser.add_argument('--frame', required=True, type=Path)
    parser.add_argument('--output', required=True, type=Path)
    args = parser.parse_args()
    result = seal(args.frame, args.dockets)
    with args.output.open('x', encoding='utf-8', newline='\n') as stream:
        json.dump(result, stream, indent=2, sort_keys=True, ensure_ascii=False)
        stream.write('\n')


if __name__ == '__main__':
    main()
