#!/usr/bin/env python3
"""Generate a fixed synthetic case frame without computing its audit outcomes."""

import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path

FRAME_SEED = 'neurosemanticorr-r1-prospective-frame-v1-2026-11-23'


def digest(*parts):
    message = json.dumps([FRAME_SEED, *parts], ensure_ascii=True, separators=(',', ':'))
    return hashlib.sha256(message.encode('ascii')).hexdigest()


def json_bytes(value):
    return (json.dumps(value, ensure_ascii=False, indent=2, sort_keys=True) + '\n').encode('utf-8')


# Newly named design contexts are nested in the two established profile workflows.
CONTEXTS = {
    'community-library': ('W1', ('branch', 'stock', 'hours', 'visitor')),
    'district-energy': ('W1', ('meter', 'reading', 'tariff', 'building')),
    'mobility-access': ('W2', ('route', 'stop', 'platform', 'transfer')),
    'skills-bursary': ('W2', ('course', 'tuition', 'attendance', 'award')),
}

PROBES = (
    'direct_clean',
    'direct_nested_clean',
    'direct_wrong_value',
    'direct_wrong_metadata',
    'exact_alias_clean',
    'suffix_alias_clean',
    'suffix_alias_wrong_value',
    'dual_alias_equivalent',
    'dual_alias_conflict',
    'alias_chain',
    'unmapped_alias',
    'untracked_direct',
)

REPLICATES = 4


def build_frame():
    cases = []
    for context, (profile_workflow, vocabulary) in CONTEXTS.items():
        for probe in PROBES:
            for replicate in range(REPLICATES):
                identity = (context, profile_workflow, probe, replicate)
                cases.append({
                    'case_id': 'R1PROS-' + digest('case', *identity)[:24].upper(),
                    'context': context,
                    'profile_workflow': profile_workflow,
                    'rows_seed': digest('rows', *identity)[:16],
                    'probe': probe,
                    'alias_key': vocabulary[replicate] + digest('key', *identity)[:16],
                })
    cases.sort(key=lambda case: (digest('frame-order', case['case_id']), case['case_id']))
    for field in ('case_id', 'rows_seed', 'alias_key'):
        if len({case[field] for case in cases}) != len(cases):
            raise ValueError(f'Duplicate {field} across designed dossiers')
    frame = {'schema': 'nsc-r1-prospective-frame/1', 'cases': cases}
    counts = Counter((case['context'], case['probe']) for case in cases)
    design = {
        'schema': 'nsc-r1-prospective-frame-design/1',
        'source': 'new_synthetic_finite_frame',
        'seed': FRAME_SEED,
        'case_count': len(cases),
        'unit': 'one underlying dossier',
        'frame_sha256': hashlib.sha256(json_bytes(frame)).hexdigest(),
        'contexts': {
            context: {
                'profile_workflow': profile_workflow,
                'carrier_vocabulary': list(vocabulary),
                'stratum_counts': {probe: counts[context, probe] for probe in PROBES},
            } for context, (profile_workflow, vocabulary) in CONTEXTS.items()
        },
    }
    return frame, design


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--output-dir', type=Path, default=Path(__file__).resolve().parent)
    args = parser.parse_args()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    frame, design = build_frame()
    for filename, contents in (('FRAME.json', frame), ('FRAME_DESIGN_MANIFEST.json', design)):
        output_path = args.output_dir / filename
        body = json_bytes(contents)
        if output_path.exists():
            if output_path.read_bytes() != body:
                parser.error(f'Refusing to replace unequal bytes at {output_path}')
        else:
            with output_path.open('xb') as output:
                output.write(body)


if __name__ == '__main__':
    main()
