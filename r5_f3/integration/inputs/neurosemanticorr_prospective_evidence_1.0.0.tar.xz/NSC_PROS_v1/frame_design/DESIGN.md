# Synthetic held-out case frame

The frame is a finite, deliberately constructed collection of survey dossiers. Each sampling unit is one underlying dossier with one document-level question about reference resolution. All unit identities and row seeds are newly generated. The frame generator receives no historical dossier files, case outcomes or checker source. Structural strata exercise the frozen interface, so the experiment tests a designed range of situations under that interface.

Four synthetic collection contexts have distinct dossier row seeds and names. Community library and district energy use workflow profile W1. Mobility access and skills bursary use W2. Each context has 48 units drawn from 12 structural strata with four designed instances each. The two profile workflows are the established W1 and W2. The designed contexts therefore provide new cases within the established profiles. The allocation was fixed for contrast coverage. External strata frequencies, error rates, operational review costs and human performance remain unmeasured.

Every generated case uses a stable case identity beginning `R1PROS-`. A fixed seed and SHA-256 determine identifiers, alias keys, row seeds and ordering. Random selection by an audit strategy is a separate operation and its randomness is logged separately. IDs, alias keys and row seeds are unique across the frame. Repeated executions, paths or representations remain part of their original sampling unit.

The predeclared probe identifier tells the materialisation code which structural case to build. Checkers receive the resulting dossier and its evidence. Audit routing uses the materialised inputs and checker outputs according to the protocol. The generator computes case specifications. A distinct oracle implements and freezes the adjudication semantics.

Generate the two JSON files in an empty directory with `python3 generate_frame.py --output-dir /path/to/empty-directory`. The generator compares with existing files byte-for-byte and refuses to replace a mismatch. The included design manifest records the exact frame checksum.
