# Retained prospective evidence

This capsule records the original prospective audit of 192 synthetic dossiers, using the two retained P4 checker implementations. Its 384 original invocations and frozen study design remain historical evidence.

## Contents

| Path | Content |
| --- | --- |
| `00_plan/FREEZE.json` | Pre-execution commitment to the plan, inputs, reference and permutations |
| `dockets/` | The 192 original synthetic dossiers and their input inventories |
| `execution/` | Original paired checker reports, receipts and streams |
| `evaluation/BLIND_SELECTION.json` | Policy selections committed before reference scoring |
| `evaluation/PROSPECTIVE_RESULTS.json` | Original results by policy, context and case type |
| [Independent audit](report/INDEPENDENT_AUDIT.md) | Reconstruction method and retained interpretation |
| [Research report in Romanian](report/REPORT_RO.md) | Markdown report, including both result tables |
| `MANIFEST_PROSPECTIVE.json` | Current closed inventory of this distributable capsule |

## Replay

The enclosing software distribution supplies the procedures for replaying the retained results and performing fresh synthetic checker qualification. Start with its main README.

The independent historical recalculation can also be run from this extracted capsule with a new output path outside it:

```sh
python3 -B report/recompute_independent_audit.py --root . --run execution --selection evaluation/BLIND_SELECTION.json --results evaluation/PROSPECTIVE_RESULTS.json --output ../independent_audit_recomputed.json
```

The original comparison remains 32 versus 19 discovered shared errors at 112 reviews per policy. The screened policy's simultaneous upper count remains 60. A replay reconstructs that retained design; it does not create another prospective sample.

## Archive identity

This is the documentation projection distributed with neuroSEMANTICorr 1.0.0. The original technical inputs, freeze, source, raw reports and numerical results retain their bytes. The printable report is represented by its matching Markdown source. Source and distribution identities are distinguished in the manifest and in the enclosing software provenance.
