"""Read-only verifier for the closed prospective experiment archive."""
import argparse
import hashlib
import json
from pathlib import Path, PurePosixPath
import stat
from zipfile import ZipFile

PREFIX='NSC_PROS_v1/'
MANIFEST=PREFIX+'MANIFEST_PROSPECTIVE.json'

def verify(path):
    with ZipFile(path) as z:
        entries=z.infolist()
        names={x.filename for x in entries}
        if len(names)!=len(entries) or sum(x.file_size for x in entries)>150_000_000:
            raise ValueError('Duplicate names or excessive payload')
        for item in entries:
            n=item.filename
            if (not n.startswith(PREFIX) or n!=str(PurePosixPath(n)) or
                any(x in ('','.','..') for x in n.split('/')) or '\\' in n or ':' in n
                or item.is_dir() or item.flag_bits&1 or stat.S_IFMT(item.external_attr >> 16) != stat.S_IFREG):
                raise ValueError('Unsupported ZIP member '+n)
        m=json.loads(z.read(MANIFEST))
        files={PREFIX+r['path']:r for r in m['files']}
        if m['schema'] != 'nsc-r1-prospective-experiment-package/1' or not m['self_excluded'] or len(files)!=len(m['files']) or set(files)|{MANIFEST}!=names:
            raise ValueError('Manifest and inventory differ')
        for name,row in files.items():
            data=z.read(name)
            if len(data)!=row['bytes'] or hashlib.sha256(data).hexdigest()!=row['sha256']:
                raise ValueError('Manifest binding mismatch '+name)
        if z.testzip() is not None:
            raise ValueError('CRC failure')
    return {'status':'PASS_BYTE_CUSTODY_ONLY','manifested_files':len(files)}

if __name__=='__main__':
    parser=argparse.ArgumentParser(description=__doc__)
    parser.add_argument('archive',type=Path)
    args=parser.parse_args()
    print(json.dumps(verify(args.archive)))
