"""Extract the exact private P4 archive from the verified P8 continuity chain."""

import argparse
from hashlib import sha256
from io import BytesIO
from pathlib import Path
from zipfile import ZipFile


P8_SHA = "cc8f7c163f1ef2bb53d2f2349e1526277114a6a067536ef3795498119b43cf81"
P4_SHA = "01d39c2da1515e5870d6e356ac24000e89fbe0d4fad77188bd83dc2a6b31625a"
ARCHIVE_CHAIN = (
    (
        "NSC_P8_v1/continuity/neuroSEMANTICorr_v12_P7_CONTINUITATE_COMPLETA.zip",
        "9c72f7b45f50054339e40408a78f00f13b32d4ccc9ed8aaf501c0818508c3065",
    ),
    (
        "NSC_P7_v1/continuity/neuroSEMANTICorr_v12_P6_CONTINUITATE_COMPLETA.zip",
        "8a0ff67224524482e12a9e5f4201e25de0e963cf8c9ae7d9cc56be5e68381f43",
    ),
    (
        "NSC_P6_v1/continuity/neuroSEMANTICorr_v12_P5_CONTINUITATE_COMPLETA.zip",
        "5de8affd5859c3f009fa8a939c24abf1f3128f11795b45c804178b42b3e11ad1",
    ),
    (
        "NSC_P5_v1/continuity/neuroSEMANTICorr_v12_P4_BENCHMARK_COMPLET.zip",
        P4_SHA,
    ),
)

def verify(condition, label):
    if not condition:
        raise ValueError(label)


def digest(content):
    return sha256(content).hexdigest()


def archived_p4(path):
    data = path.read_bytes()
    actual = digest(data)
    if actual == P4_SHA:
        return data
    verify(actual == P8_SHA, "Input must be the exact frozen P8 or P4 continuity archive")
    for member, expected in ARCHIVE_CHAIN:
        with ZipFile(BytesIO(data)) as archive:
            data = archive.read(member)
        verify(digest(data) == expected, f"Archive hash mismatch for {member}")
    return data


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('source', type=Path)
    parser.add_argument('output', type=Path)
    args = parser.parse_args()
    archive = archived_p4(args.source)
    with args.output.open('xb') as out:
        out.write(archive)
    print(f'{P4_SHA}  {args.output}')


if __name__ == '__main__':
    main()
