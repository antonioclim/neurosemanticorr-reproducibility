"""Turn new synthetic frame recipes into neutral P4-format evidence bundles."""

import argparse
from collections import Counter, defaultdict
from fractions import Fraction
import json
from pathlib import Path
import random
import re
from zipfile import ZipFile

from run_archived_pair import (
    ARCHIVE_ROOT, ARCHIVE_SHA256, DOSSIER_ID, digest, input_manifest, json_bytes,
    path_digest, read_json_bytes, require, sha256_file, write_exclusive,
)


FRAME_SCHEMA = 'nsc-r1-prospective-frame/1'
FAMILIES = {
    'direct_clean', 'direct_nested_clean', 'direct_wrong_value', 'direct_wrong_metadata',
    'exact_alias_clean', 'suffix_alias_clean', 'suffix_alias_wrong_value',
    'dual_alias_equivalent', 'dual_alias_conflict', 'alias_chain', 'unmapped_alias',
    'untracked_direct',
}
TEMPLATE_PREFIX = ARCHIVE_ROOT + '01_protocol/'


def exact_json(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'),
                      ensure_ascii=False, allow_nan=False).encode('utf-8')


def fraction_record(number):
    value = Fraction(number)
    return {'numerator': value.numerator, 'denominator': value.denominator}


def undefined(reason):
    return {'status': 'UNDEFINED', 'reason': reason}


def neutral_templates(archive_path):
    with archive_path.open('rb') as source:
        require(sha256_file(source) == ARCHIVE_SHA256, 'Neutral templates need the exact P4 archive')
        with ZipFile(source) as archive:
            frame = read_json_bytes(archive.read(TEMPLATE_PREFIX + 'NEUTRAL_UNIT_EXAMPLES.json'))
            templates = {}
            for example in frame['examples']:
                workflow = example['workflow']
                prefix = TEMPLATE_PREFIX + f'NEUTRAL_UNIT_BUNDLES/{workflow}/'
                entries = {}
                for item in example['files']:
                    name = item['path']
                    raw = archive.read(prefix + name)
                    require(len(raw) == item['bytes'] and digest(raw) == item['sha256'],
                            f'Neutral template file mismatch: {workflow} {name}')
                    if name != 'inventory.json':
                        entries[name] = raw
                templates[workflow] = entries
    require(set(templates) == {'W1', 'W2'}, 'Expected the two neutral workflow templates')
    return templates


def members(rows, name, accept):
    accepted = [(index, row['id']) for index, row in enumerate(rows) if accept(row)]
    return {'population_id': name, 'ids': [key for index, key in accepted],
            'local_to_source_positions': [index for index, key in accepted]}


def w1_documents(recipe, randomiser, loaded):
    size = randomiser.randint(5, 14)
    labels = loaded['records/R08_measurement_policy.json']['category_order']
    states = ['observed', 'observed', 'observed']
    states += randomiser.choices(['observed', 'refusal', 'item_nonresponse', 'structural_skip'], k=size-3)
    randomiser.shuffle(states)
    rows = [{'id': f"{recipe['case_id']}-R{index+1:02d}",
             'readiness': randomiser.choice(labels) if state == 'observed' else None}
            for index, state in enumerate(states)]
    source_facts = [{'id': row['id'], 'state': state} for row, state in zip(rows, states)]
    observed = [row['readiness'] for row in rows if row['readiness'] is not None]
    counts = dict.fromkeys(labels, 0)
    for label in observed:
        counts[label] += 1
    n = len(observed)
    values = {'denominator': n, 'counts': counts,
              'proportions': {label: fraction_record(Fraction(count, n)) for label, count in counts.items()}}
    endpoints = [('/values/denominator', n, 'rows', n)]
    label = randomiser.choice(labels)
    endpoints.append((f'/values/proportions/{label}', values['proportions'][label], 'proportion', n))
    profile = loaded['records/R08_measurement_policy.json']
    return (rows, source_facts, rows, [members(rows, 'eligible', lambda row: row['readiness'] is not None)],
            {'category_order': labels, 'display_codes': profile['display_codes'], 'selected_labels': observed},
            values, endpoints)


def w2_documents(recipe, randomiser):
    size = randomiser.randint(5, 12)
    rows = []
    for index in range(size):
        staff = randomiser.randint(3, 70) if index == 0 or (index != 1 and randomiser.random() < 0.7) else None
        turnover = randomiser.randint(35, 210) if index in (0, 1) or randomiser.random() < 0.7 else None
        other = randomiser.randint(-13, 24) if randomiser.random() < 0.8 else None
        rows.append({'id': f"{recipe['case_id']}-R{index+1:02d}", 'staff': staff,
                     'turnover': turnover, 'other.rev': other, 'total.rev': (turnover or 30) + randomiser.randint(1, 95)})
    workers = [row['staff'] for row in rows if row['staff'] is not None]
    turnovers = [row['turnover'] for row in rows if row['turnover'] is not None]
    mean_staff, mean_turnover = Fraction(sum(workers), len(workers)), Fraction(sum(turnovers), len(turnovers))
    factor = mean_staff / mean_turnover
    facts, output = [], []
    for row in rows:
        staff, turnover, other = row['staff'], row['turnover'], row['other.rev']
        if staff is not None:
            recorded_staff, staff_change = fraction_record(staff), 'unchanged'
        elif turnover is not None:
            recorded_staff, staff_change = fraction_record(factor * turnover), 'imputed'
        else:
            recorded_staff, staff_change = undefined('MISSING_INPUT'), 'undefined'
        other_change = 'imputed' if other is None else 'edited' if other < 0 else 'unchanged'
        facts.append({'id': row['id'], 'staff_input': 'missing' if staff is None else 'available',
                      'turnover_input': 'missing' if turnover is None else 'available',
                      'staff_change': staff_change, 'other_rev_change': other_change})
        output.append({'id': row['id'], 'staff': recorded_staff, 'other.rev': fraction_record(abs(other or 0)),
                       'turnover_ratio': undefined('MISSING_TURNOVER') if turnover is None
                       else fraction_record(Fraction(turnover, row['total.rev']))})
    populations = [members(rows, 'staff_available', lambda row: row['staff'] is not None),
                   members(rows, 'turnover_available', lambda row: row['turnover'] is not None),
                   members(rows, 'staff_imputation', lambda row: row['staff'] is None and row['turnover'] is not None)]
    values = {'mean_staff': fraction_record(mean_staff), 'mean_turnover': fraction_record(mean_turnover),
              'ratio': fraction_record(factor)}
    for destination, origin in (('staff_output', 'staff'), ('other_rev_output', 'other.rev'),
                                ('turnover_ratio', 'turnover_ratio')):
        values[destination] = {row['id']: row[origin] for row in output}
    finite_turnover_ratio = output[0]
    endpoints = [('/values/mean_staff', values['mean_staff'], 'staff', len(workers)),
                 (f"/values/turnover_ratio/{finite_turnover_ratio['id']}",
                  finite_turnover_ratio['turnover_ratio'], 'ratio', 1)]
    return rows, facts, output, populations, {'rows': rows}, values, endpoints


def claim_records(recipe, result_id, endpoints):
    case_id, key, probe = (recipe[field] for field in ('case_id', 'alias_key', 'probe'))
    main, nested = endpoints
    pointer, value, _, _ = nested if probe == 'direct_nested_clean' else main
    metadata = {route: {'unit': unit, 'denominator': denominator, 'scope': 'finite_table'}
                for route, _, unit, denominator in endpoints}
    reference = pointer
    full = 'alias:' + key
    maps = {}
    if probe == 'exact_alias_clean':
        maps, reference = {full: main[0]}, full
    elif probe in {'suffix_alias_clean', 'suffix_alias_wrong_value'}:
        maps, reference = {key: main[0]}, full
    elif probe == 'dual_alias_equivalent':
        maps, reference = {full: main[0], key: main[0]}, full
    elif probe == 'dual_alias_conflict':
        maps, reference = {full: main[0], key: nested[0]}, full
    elif probe == 'alias_chain':
        next_alias = full + 'next'
        maps, reference = {full: next_alias, next_alias: main[0]}, full
    elif probe == 'unmapped_alias':
        reference = full
    claim = {'claim_id': case_id + '-claim01', 'source_pointer': reference,
             'value': value, **metadata[pointer]}
    if probe in {'direct_wrong_value', 'suffix_alias_wrong_value'}:
        if type(value) is int:
            claim['value'] = value + 1
        else:
            claim['value'] = fraction_record(Fraction(value['numerator'], value['denominator']) + 1)
    if probe == 'direct_wrong_metadata':
        claim['denominator'] += 1
    if probe == 'untracked_direct':
        del metadata[pointer]
    return {'claims': [claim]}, {'result_id': result_id, 'aliases': maps, 'field_metadata': metadata}


def dossier(recipe, template):
    case_id, workflow = recipe['case_id'], recipe['profile_workflow']
    loaded = {name: read_json_bytes(raw) for name, raw in template.items() if name.endswith('.json')}
    randomiser = random.Random(int(recipe['rows_seed'], 16))
    if workflow == 'W1':
        documents = w1_documents(recipe, randomiser, loaded)
    else:
        documents = w2_documents(recipe, randomiser)
    rows, source_facts, output, populations, operands, values, endpoints = documents
    result_id = case_id + '-result'
    result = {**loaded['records/R11_result.json'], 'result_id': result_id, 'operands': operands, 'values': values}
    claim, edges = claim_records(recipe, result_id, endpoints)
    semantic_payload = {'study': f"{recipe['context']}/{case_id}", 'revision': 1, 'active': True}
    semantic_digest = {'domain': 'canonical-json-v1', 'algorithm': 'sha256',
                       'value': digest(exact_json(semantic_payload))}
    task_ids = [f'{case_id}-T{index+1:02d}' for index in range(randomiser.randint(3, 7))]
    statuses = [*('SUCCEEDED', 'FAILED', 'UNATTEMPTED'),
                *randomiser.choices(['SUCCEEDED', 'FAILED', 'UNATTEMPTED'], k=len(task_ids)-3)]
    counts = Counter(statuses)
    tasks = dict(zip(task_ids, statuses))
    if randomiser.getrandbits(1):
        tasks = [{'task_id': name, 'status': status} for name, status in tasks.items()]
    data_ids = [row['id'] for row in rows]
    loaded.update({
        'semantic_payload.json': semantic_payload,
        'data/rows.json': {'rows': rows},
        'data/states_or_change_facts.json': {'rows': source_facts},
        'data/output_rows.json': {'rows': output},
        'records/R01.json': {'semantic_digest': semantic_digest},
        'records/R03.json': {**loaded['records/R03.json'], 'declared': {'strict': True} if randomiser.getrandbits(1) else {}},
        'records/R04.json': {**loaded['records/R04.json'], 'workspace': f"/prospective/{recipe['context']}/{case_id}"},
        'records/R05_alignment_receipt.json': {'data_ids': data_ids, 'state_ids': data_ids,
                                              'initial_pairing_verified': False, 'producer_authenticated': False},
        'records/R06_materialisation.json': {'populations': populations},
        'records/R11_result.json': result,
        'records/R12_consumer.json': {field: result[field] for field in ('result_id', 'status', 'values')},
        'records/R13.json': {'counts': dict(counts), 'reported_attempted_denominator': counts['SUCCEEDED']+counts['FAILED'], 'tasks': tasks},
        'records/R13_task_universe.json': {'task_ids': task_ids},
        'records/R14.json': {**loaded['records/R14.json'], 'task_id': task_ids[1]},
        'records/R14_wait_receipt.json': {**loaded['records/R14_wait_receipt.json'], 'task_id': task_ids[1]},
        'records/R15_claims.json': claim,
        'records/R15_edges.json': edges,
    })
    parts = dict(template)
    parts.update({path: exact_json(obj) + b'\n' for path, obj in loaded.items()})
    parts['inventory.json'] = exact_json({'members': [
        {'path': path, 'bytes': len(raw), 'sha256': digest(raw)} for path, raw in sorted(parts.items())
    ]}) + b'\n'
    return parts


def load_frame(path):
    frame = read_json_bytes(path.read_bytes())
    require(frame['schema'] == FRAME_SCHEMA, 'Unexpected prospective frame schema')
    found_ids = set()
    alias_keys = set()
    seeds = set()
    per_context = defaultdict(Counter)
    for recipe in frame['cases']:
        case_id, workflow = recipe['case_id'], recipe['profile_workflow']
        require(DOSSIER_ID.fullmatch(case_id) and case_id.startswith('R1PROS-') and case_id not in found_ids,
                f'Invalid or reused prospective case ID {case_id}')
        require(workflow in {'W1', 'W2'}, 'Profile workflows restricted to W1 and W2')
        require(re.fullmatch(r'[0-9a-f]{16}', recipe['rows_seed']) and recipe['rows_seed'] not in seeds,
                f'Invalid or reused prospective rows seed {case_id}')
        require(re.fullmatch(r'[A-Za-z][A-Za-z0-9]*', recipe['alias_key']) and recipe['alias_key'] not in alias_keys,
                f'Invalid or reused prospective alias key {case_id}')
        require(recipe['probe'] in FAMILIES and recipe['context'], 'Unexpected prospective case recipe')
        found_ids.add(case_id)
        alias_keys.add(recipe['alias_key'])
        seeds.add(recipe['rows_seed'])
        per_context[recipe['context']][recipe['probe']] += 1
    require(frame['cases'], 'Empty prospective case frame')
    return frame, per_context


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    for flag in ('p4', 'frame', 'dockets', 'input-manifest', 'receipt'):
        parser.add_argument('--' + flag, type=Path, required=True)
    args = parser.parse_args()
    require(not args.input_manifest.exists() and not args.receipt.exists(), 'Refusing to overwrite materialisation receipts')
    frame, tally = load_frame(args.frame)
    templates = neutral_templates(args.p4)
    args.dockets.mkdir(parents=True, exist_ok=False)
    for recipe in frame['cases']:
        parts = dossier(recipe, templates[recipe['profile_workflow']])
        for relpath, raw in parts.items():
            path = args.dockets / recipe['case_id'] / relpath
            path.parent.mkdir(parents=True, exist_ok=True)
            write_exclusive(path, raw)
    manifest = input_manifest(args.dockets)
    write_exclusive(args.input_manifest, json_bytes(manifest))
    write_exclusive(args.receipt, json_bytes({
        'schema': 'nsc-pros-p4-materialisation/1', 'P4_archive_sha256': ARCHIVE_SHA256,
        'frame_sha256': path_digest(args.frame), 'materialiser_sha256': path_digest(Path(__file__)),
        'implementation_input_manifest_sha256': path_digest(args.input_manifest),
        'cases': len(frame['cases']), 'synthetic_contexts_by_probe': tally,
        'dossier_member_count': sum(len(case['files']) for case in manifest['cases']),
        'derivation': 'Neutral P4 unit scaffolding only. New seeded row data, case/row/result/task identifiers, claims, and raw inventory. No candidate invocation.',
    }))


if __name__ == '__main__':
    main()
