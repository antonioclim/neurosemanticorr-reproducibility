"""Run the byte-verified P4 primaries on a separately frozen dossier frame."""

import argparse
from collections import Counter
from hashlib import sha256
import json
import os
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import tempfile
from zipfile import ZipFile


ARCHIVE_ROOT = "NSC_P4_RECOVERY_v2/"
ARCHIVE_SHA256 = "01d39c2da1515e5870d6e356ac24000e89fbe0d4fad77188bd83dc2a6b31625a"
SOURCES = {
    "T_FULL": ("02_implementations/t_full/checker.py",
               "9d8153640e47fb74d154af547d7119ff92bb67be53f9b395f5a559700e5e2d10"),
    "B_ASSERT": ("02_implementations/b_assert/checker.py",
                 "3266ca109c7cea6f5fe9a1aeb0bdf9a8e46d808787708b36551a5e4ff03fc59e"),
    "profile": ("01_protocol/FIXED_PROFILE.json",
                "e71c7435494dcf5e27163cdbf10bbb63baa57390465d1695ec9597f3a9dc448d"),
}
OBLIGATIONS = {f"O{i:02d}" for i in range(1, 17)}
TIMEOUT_SECONDS = 10
MANIFEST_SCHEMA = "nsc-pros-p4-implementation-inputs/1"
OUTPUT_SCHEMA = "nsc-pros-p4-paired-execution/1"
DOSSIER_ID = re.compile(r"[A-Za-z0-9][A-Za-z0-9_-]{0,99}")


def require(condition, explanation):
    if not condition:
        raise ValueError(explanation)


def digest(content):
    return sha256(content).hexdigest()


def path_digest(path):
    with path.open("rb") as handle:
        return sha256_file(handle)


def sha256_file(handle):
    result = sha256()
    for chunk in iter(lambda: handle.read(1024 * 1024), b""):
        result.update(chunk)
    return result.hexdigest()


def json_bytes(data):
    return (json.dumps(data, sort_keys=True, allow_nan=False, indent=2) + "\n").encode()


def unique_pairs(pairs):
    data = dict(pairs)
    require(len(data) == len(pairs), "JSON has a duplicate member")
    return data


def read_json_bytes(content):
    return json.loads(content, object_pairs_hook=unique_pairs)


def write_exclusive(path, content):
    with path.open("xb") as handle:
        handle.write(content)


def p4_sources(archive_path):
    with archive_path.open("rb") as archive_file:
        require(sha256_file(archive_file) == ARCHIVE_SHA256,
                "P4 archive is outside the recognised continuity chain")
        with ZipFile(archive_file) as archive:
            manifest = read_json_bytes(archive.read(ARCHIVE_ROOT + "01_protocol/FROZEN_ARMS_MANIFEST.json"))
            official = {arm['arm_id']: arm for arm in manifest['arms']}
            require(manifest['profile_sha256'] == SOURCES['profile'][1], "P4 profile manifest mismatch")
            for arm in ("T_FULL", "B_ASSERT"):
                entrypoint, recorded_hash = SOURCES[arm]
                require(official[arm]['sha256'] == recorded_hash
                        and official[arm]['entrypoint'].endswith('/' + entrypoint),
                        f"Frozen P4 manifest does not bind {arm}")
            source_bytes = {key: archive.read(ARCHIVE_ROOT + member)
                            for key, (member, _) in SOURCES.items()}
    for key, content in source_bytes.items():
        require(digest(content) == SOURCES[key][1], f"P4 byte digest mismatch for {key}")
    return source_bytes


def file_inventory(directory):
    require(not directory.is_symlink() and directory.is_dir(), f"Expected dossier directory: {directory}")
    inventory = []
    for entry in sorted(directory.rglob('*')):
        mode = entry.lstat().st_mode
        if stat.S_ISDIR(mode):
            continue
        require(stat.S_ISREG(mode), f"Non-regular dossier member: {entry}")
        inventory.append({"path": entry.relative_to(directory).as_posix(),
                          "bytes": entry.stat().st_size, "sha256": path_digest(entry)})
    return inventory


def input_manifest(dockets):
    require(dockets.is_dir() and not dockets.is_symlink(), "Expected ordinary dockets directory")
    cases = []
    for dossier in sorted(dockets.iterdir()):
        require(DOSSIER_ID.fullmatch(dossier.name) is not None, f"Invalid new case ID: {dossier.name}")
        require(not dossier.name.startswith("P3BENCH"), f"P4 benchmark identity reused: {dossier.name}")
        members = file_inventory(dossier)
        require(any(member['path'] == 'bundle.json' for member in members),
                f"Missing dossier binding for {dossier.name}")
        cases.append({"case_id": dossier.name, "files": members})
    require(cases, "Empty dossiers frame")
    return {"schema": MANIFEST_SCHEMA, "P4_archive_sha256": ARCHIVE_SHA256,
            "sources": {key: {"member": member, "sha256": sha}
                        for key, (member, sha) in SOURCES.items()}, "cases": cases}


def verify_report(path, case_id, invocation_id, arm):
    raw = path.read_bytes()
    report = read_json_bytes(raw)
    require(report.get('schema') == 'nsc-p4-checker-report/2', 'Unexpected report schema')
    require(all(report.get(key) == value for key, value in {
        'case_id': case_id, 'invocation_id': invocation_id, 'arm_id': arm,
    }.items()), 'Report identity mismatch')
    vector = report.get('obligation_vector')
    require(type(vector) is dict and set(vector) == OBLIGATIONS
            and all(value in ('S', 'V', 'U') for value in vector.values()),
            'Unexpected obligation vector')
    coverage = report.get('coverage_mask')
    require(type(coverage) is dict and set(coverage) == OBLIGATIONS
            and all(value is True for value in coverage.values()), 'Incomplete obligation coverage')
    require(type(report.get('diagnostics')) is list, 'Unexpected diagnostics schema')
    expected_aggregate = 'REJECT' if 'V' in vector.values() else (
        'INDETERMINATE' if 'U' in vector.values() else 'ALLOW_WITHIN_SCOPE')
    require(report.get('aggregate') == expected_aggregate, 'Report aggregate/vector mismatch')
    return {"bytes": len(raw), "sha256": digest(raw), "obligation_vector": vector,
            "aggregate": expected_aggregate}


def run_one(case_id, arm, dockets, staged, output, runtime, frozen_members):
    argv = [str(runtime), '-I', str(staged / f'{arm}.py'),
            '--case-bundle', str(dockets), '--profile', str(staged / 'profile.json'),
            '--case-id', case_id, '--invocation-id', f'PROS1-{case_id}-{arm}',
            '--arm-id', arm, '--output', str(output / f'{arm}.json')]
    path = output / f'{arm}.json'
    receipt = {'arm_id': arm, 'case_id': case_id, 'invocation_id': argv[argv.index('--invocation-id')+1],
               'report_path': f'{case_id}/{arm}.json', 'exit_code': None}
    try:
        proc = subprocess.run(argv, cwd=staged, stdin=subprocess.DEVNULL,
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                              env={'PATH': os.defpath, 'LC_ALL': 'C.UTF-8'}, timeout=TIMEOUT_SECONDS,
                              check=False)
        stdout, stderr = proc.stdout, proc.stderr
        receipt['exit_code'] = proc.returncode
        receipt['status'] = 'PROCESS_FAILED' if proc.returncode else 'COMPLETED_INVALID_REPORT'
    except subprocess.TimeoutExpired as error:
        stdout, stderr = error.stdout or b'', error.stderr or b''
        receipt['status'] = 'PROCESS_TIMEOUT'
    if path.is_file():
        receipt['raw_report_sha256'] = path_digest(path)
    if receipt['status'] == 'COMPLETED_INVALID_REPORT':
        try:
            receipt.update(verify_report(path, case_id, receipt['invocation_id'], arm))
            receipt['status'] = 'COMPLETED_VALID'
        except (OSError, AttributeError, ValueError) as error:
            receipt['report_problem'] = str(error)
    for stream, content in (('stdout', stdout), ('stderr', stderr)):
        name = f'{arm}.{stream}.txt'
        write_exclusive(output / name, content)
        receipt[stream] = {'path': f'{case_id}/{name}', 'bytes': len(content), 'sha256': digest(content)}
    verify_staged_sources(staged)
    require(file_inventory(dockets) == frozen_members, f"Checker altered dossier bytes for {case_id}")
    write_exclusive(output / f'{arm}.receipt.json', json_bytes(receipt))
    return receipt


def verify_staged_sources(staged):
    for key, (_, expected) in SOURCES.items():
        path = staged / ('profile.json' if key == 'profile' else f'{key}.py')
        require(path_digest(path) == expected, f"Staged candidate/profile mutation: {key}")


def execute(args):
    material = args.input_manifest.read_bytes()
    freeze_bytes = args.freeze.read_bytes()
    actual_freeze_sha = digest(freeze_bytes)
    require(actual_freeze_sha == args.freeze_sha256, 'Freeze SHA-256 mismatch')
    lock = read_json_bytes(freeze_bytes)
    require(lock.get('implementation_input_manifest_sha256') == digest(material),
            'Freeze does not bind this input manifest')
    require(lock.get('implementation_runner_sha256') == path_digest(Path(__file__)),
            'Freeze does not bind this runner file')
    frozen = read_json_bytes(material)
    require(frozen == input_manifest(args.dockets), 'Frozen framed dossier bytes changed')
    sources = p4_sources(args.p4)
    runtime = Path(sys.executable).resolve()
    output = args.output.absolute()
    require(not output.is_relative_to(args.dockets.resolve()), 'Output must be outside dockets')
    output.mkdir(parents=True, exist_ok=False)
    invocation_statuses = Counter()
    schedule = []
    with tempfile.TemporaryDirectory(prefix='nsc-pros-candidate-') as workspace:
        staged = Path(workspace).resolve()
        for key, content in sources.items():
            path = staged / ('profile.json' if key == 'profile' else f'{key}.py')
            write_exclusive(path, content)
            path.chmod(0o400)
        for index, case in enumerate(frozen['cases']):
            case_id = case['case_id']
            case_output = output / case_id
            case_output.mkdir()
            dockets = staged / case_id
            shutil.copytree(args.dockets / case_id, dockets)
            require(file_inventory(dockets) == case['files'], f'Staged case bytes changed: {case_id}')
            order = ('T_FULL', 'B_ASSERT') if index % 2 == 0 else ('B_ASSERT', 'T_FULL')
            for arm in order:
                receipt = run_one(case_id, arm, dockets, staged, case_output, runtime, case['files'])
                invocation_statuses[receipt['status']] += 1
                path = case_output / f'{arm}.receipt.json'
                schedule.append({'case_id': case_id, 'arm_id': arm, 'status': receipt['status'],
                                 'receipt_path': f'{case_id}/{arm}.receipt.json', 'sha256': path_digest(path)})
            shutil.rmtree(dockets)
        verify_staged_sources(staged)
    require(frozen == input_manifest(args.dockets), 'Original dossiers changed during execution')
    summary = {'schema': OUTPUT_SCHEMA, 'freeze_sha256': actual_freeze_sha,
               'implementation_input_manifest_sha256': digest(material),
               'implementation_runner_sha256': path_digest(Path(__file__)),
               'P4_archive_sha256': ARCHIVE_SHA256, 'sources': frozen['sources'],
               'python': {'interpreter': runtime.name, 'sha256': path_digest(runtime),
                          'version': sys.version, 'platform': sys.platform, 'isolation_flag': '-I'},
               'launch_timeout_seconds': TIMEOUT_SECONDS, 'cases': len(frozen['cases']),
               'expected_invocations': 2 * len(frozen['cases']),
               'operational_statuses': dict(invocation_statuses), 'schedule': schedule}
    write_exclusive(output / 'RUN_RECEIPT.json', json_bytes(summary))
    print(json.dumps({key: value for key, value in summary.items() if key != 'schedule'}, indent=2))


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    subs = parser.add_subparsers(dest='operation', required=True)
    stage = subs.add_parser('manifest')
    stage.add_argument('--dockets', type=Path, required=True)
    stage.add_argument('--output', type=Path, required=True)
    inspect = subs.add_parser('inspect-sources')
    inspect.add_argument('--p4', type=Path, required=True)
    run = subs.add_parser('execute')
    for flag in ('p4', 'dockets', 'input-manifest', 'freeze', 'output'):
        run.add_argument('--' + flag, type=Path, required=True)
    run.add_argument('--freeze-sha256', required=True)
    args = parser.parse_args()
    if args.operation == 'manifest':
        write_exclusive(args.output, json_bytes(input_manifest(args.dockets)))
    elif args.operation == 'inspect-sources':
        print(json.dumps({name: {'bytes': len(content), 'sha256': digest(content)}
                          for name, content in p4_sources(args.p4).items()}, indent=2))
    else:
        execute(args)


if __name__ == '__main__':
    main()
