# Execution of the archived checker pair

The retained P4 continuity archive supplies the two exact primary entrypoints and the fixed profile. The prospective runner verifies the archive digest, the original frozen-arm bindings and all three extracted byte digests before use.

| Component | P4 archive member beneath `NSC_P4_RECOVERY_v2/` | SHA-256 |
| --- | --- | --- |
| T_FULL | `02_implementations/t_full/checker.py` | `9d8153640e47fb74d154af547d7119ff92bb67be53f9b395f5a559700e5e2d10` |
| B_ASSERT | `02_implementations/b_assert/checker.py` | `3266ca109c7cea6f5fe9a1aeb0bdf9a8e46d808787708b36551a5e4ff03fc59e` |
| Fixed profile | `01_protocol/FIXED_PROFILE.json` | `e71c7435494dcf5e27163cdbf10bbb63baa57390465d1695ec9597f3a9dc448d` |

Each independent invocation uses `python3 -I`, the archived entrypoint, the staged dossier file tree, the archived fixed profile and fresh prospective IDs. The two primaries receive identical dossier bytes. The runner alternates their order. It checks the files after each execution and checks the exact output schema, invocation identity, obligation vector, coverage and aggregate action. Timeout, process failure and invalid report remain distinct operational outcomes. Raw stdout, stderr, reports and receipts preserve diagnostics. The isolated Python mode and temporary directory limit interpreter path and evidence interference. They provide no independent operating-system sandbox. This experiment uses single functional invocations rather than timing observations.

The frozen profile supports W1 and W2. The new synthetic contexts, dataset rows and case identities instantiate those models. The materialiser derives fixed documentary scaffolding from the archived neutral unit examples. It constructs fresh aligned rows, populations, arithmetic records, task accounting and claim records before rebuilding each raw inventory. It never invokes a checker. The materialisation receipt and QA document counts, identity and byte relationships.

The private prospective wrapper needs the byte-identical local P4 continuity archive. It carries no candidate source as a separately redistributed component. The inherited project's rights decision remains the applicable record for any proposed external use.
